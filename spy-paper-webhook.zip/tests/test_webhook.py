import json
import sqlite3
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient

from app import Settings, create_app

TOKEN = "test-token-" + "x" * 40


@pytest.fixture
def setup(tmp_path):
    now = [datetime(2026, 10, 9, 14, 0, tzinfo=timezone.utc)]
    settings = Settings(TOKEN, str(tmp_path / "events.sqlite3"), str(tmp_path / "PAUSED"))
    client = TestClient(create_app(settings, lambda: now[0]))
    payload = dict(token=TOKEN, trade_id="SPY-1", action="ENTRY", timestamp=now[0].isoformat(),
                   symbol="SPY", direction="CALL", entry=600, stop=599, target=602)
    return client, payload, settings, now


def test_entry_duplicate_exit_and_restart(setup):
    client, payload, settings, now = setup
    response = client.post("/webhook", json=payload)
    assert response.status_code == 200 and response.json()["broker_order_sent"] is False
    restarted = TestClient(create_app(settings, lambda: now[0]))
    assert restarted.post("/webhook", json=payload).json()["status"] == "duplicate"
    assert restarted.post("/webhook", json={**payload, "trade_id": "SPY-2"}).status_code == 409
    assert restarted.post("/webhook", json={**payload, "action": "EXIT_TP"}).status_code == 200
    with sqlite3.connect(settings.database) as db:
        records = db.execute("SELECT payload FROM events").fetchall()
    assert len(records) == 2 and TOKEN not in json.dumps(records)
    assert client.get("/health").json()["broker_orders_enabled"] is False


@pytest.mark.parametrize("changes,status", [
    ({"token": "wrong" * 10}, 401), ({"symbol": "QQQ"}, 422),
    ({"stop": 601}, 422), ({"entry": "NaN"}, 422), ({"unexpected": 1}, 422),
    ({"timestamp": "2026-10-09T14:00:00"}, 422),
    ({"timestamp": "2026-10-09T13:58:00Z"}, 422),
    ({"timestamp": "2026-10-09T14:01:00Z"}, 422),
])
def test_reject_bad_alerts(setup, changes, status):
    client, payload, _, _ = setup
    response = client.post("/webhook", json={**payload, **changes})
    assert response.status_code == status
    assert TOKEN not in response.text


def test_put_and_conflicting_event(setup):
    client, payload, _, _ = setup
    payload.update(direction="PUT", stop=601, target=598)
    assert client.post("/webhook", json=payload).status_code == 200
    assert client.post("/webhook", json={**payload, "target": 597}).status_code == 409
    assert client.post("/webhook", json={**payload, "action": "EXIT_SL", "stop": 602}).status_code == 409


def test_pause_and_body_size(setup):
    client, payload, settings, _ = setup
    from pathlib import Path
    Path(settings.kill_file).touch()
    assert client.post("/webhook", json=payload).status_code == 503
    assert client.post("/webhook", content="x" * 9000,
                       headers={"content-type": "application/json"}).status_code == 413
    assert client.post("/webhook", content="plain text").status_code == 415


def test_session_cooldown_and_daily_limit(setup):
    client, payload, _, now = setup
    for index in range(5):
        payload.update(trade_id=f"SPY-{index}", timestamp=now[0].isoformat())
        assert client.post("/webhook", json=payload).status_code == 200
        assert client.post("/webhook", json={**payload, "action": "EXIT_TP"}).status_code == 200
        if index == 0:
            assert client.post("/webhook", json={**payload, "trade_id": "too-soon"}).status_code == 429
        now[0] += timedelta(seconds=61)
    payload.update(trade_id="over-limit", timestamp=now[0].isoformat())
    assert client.post("/webhook", json=payload).status_code == 429
    now[0] = datetime(2026, 10, 10, 14, 0, tzinfo=timezone.utc)
    payload["timestamp"] = now[0].isoformat()
    assert client.post("/webhook", json=payload).status_code == 422


def test_broker_guard_and_preview_payload(monkeypatch):
    from broker_check import client_from_env, option_order
    monkeypatch.delenv("WEBULL_APP_KEY", raising=False)
    with pytest.raises(RuntimeError):
        client_from_env()
    for name, value in {"WEBULL_APP_KEY": "test", "WEBULL_APP_SECRET": "test",
                        "WEBULL_SANDBOX_HOST": "api.webull.com",
                        "WEBULL_SANDBOX_CONFIRMED": "true"}.items():
        monkeypatch.setenv(name, value)
    with pytest.raises(RuntimeError):
        client_from_env()
    expiry = (datetime.now(timezone.utc).date() + timedelta(days=10)).isoformat()
    order = option_order("CALL", "600", expiry, "2.50")
    assert order["legs"][0]["instrument_type"] == "OPTION"
    assert order["quantity"] == "1" and order["time_in_force"] == "DAY"
    with pytest.raises(ValueError):
        option_order("PUT", "600", expiry, "3.01")
