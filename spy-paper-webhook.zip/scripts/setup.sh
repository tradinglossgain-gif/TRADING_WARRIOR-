#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
.venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt
.venv/bin/python - <<'PY'
import os
import secrets
from pathlib import Path
directory = Path('.local')
directory.mkdir(mode=0o700, exist_ok=True)
directory.chmod(0o700)
token = directory / 'webhook-token'
if not token.exists():
    fd = os.open(token, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as stream:
        stream.write(secrets.token_hex(32) + '\n')
token.chmod(0o600)
print('Local webhook token prepared; value is not displayed.')
PY
