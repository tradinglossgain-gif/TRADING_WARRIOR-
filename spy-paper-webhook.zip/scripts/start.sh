#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export WEBHOOK_TOKEN_FILE="${WEBHOOK_TOKEN_FILE:-$PWD/.local/webhook-token}"
export DATABASE_PATH="${DATABASE_PATH:-$PWD/.local/events.sqlite3}"
export KILL_SWITCH_FILE="${KILL_SWITCH_FILE:-$PWD/.local/PAUSED}"
exec .venv/bin/uvicorn app:application --factory --host "${BIND_HOST:-127.0.0.1}" --port "${PORT:-8000}" --workers 1 --no-access-log
